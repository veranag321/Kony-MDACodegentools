AccountModuleConfig = {
    'BusinessControllerConfig': {
        'CommandHandler': [
                           {
                           'CommandId': 'GetAccounts',
                           'CommandHandler': 'GetAccounts_CommandHandler',
                           'CommandHandlerExtension':'GetAccounts_CommandHandlerExtension'
                           }
        ],
        'BusinessControllerClass': 'Account_BusinessController'
    },
    'PresentationControllerConfig':{
        "Default":{
            'PresentationControllerClass': 'Account_PresentationController',
            'PresentationExtensions': ['Account_PresentationController_Extn']
        }
    },
            'Forms':[
                        {
               'FormName' : 'frmHome',
               'Controller' : 'frmHomeController',
               'FormController' : 'kony.mvc.MDAFormController',
               'ControllerExtensions' : []
            },
            {
               'FormName' : 'frmDummy',
               'Controller' : 'frmDummyController',
               'FormController' : 'kony.mvc.MDAFormController',
               'ControllerExtensions' : []
            }
    ],
    'ModuleName': 'AccountModule'
};
