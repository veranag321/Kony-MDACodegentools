TransactionModuleConfig = {
    'BusinessControllerConfig': {
        'CommandHandler': [
                           {
                           'CommandId': 'GetTransactions',
                           'CommandHandler': 'GetTransactions_CommandHandler',
                           'CommandHandlerExtension':'GetTransactions_CommandHandlerExtension'
                           }
        ],
        'BusinessControllerClass': 'Transaction_BusinessController'
    },
    'PresentationControllerConfig':{
        "Default":{
            'PresentationControllerClass': 'Transaction_PresentationController',
            'PresentationExtensions': ['Transaction_PresentationController_Extn']
        }
    },
            'Forms':[
                        {
               'FormName' : 'frmTransactions',
               'Controller' : 'frmTransactionsController',
               'FormController' : 'kony.mvc.MDAFormController',
               'ControllerExtensions' : []
            }
    ],
    'ModuleName': 'TransactionModule'
};
