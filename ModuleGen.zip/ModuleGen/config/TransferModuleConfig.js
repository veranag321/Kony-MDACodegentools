TransferModuleConfig = {
    'BusinessControllerConfig': {
        'CommandHandler': [
                           {
                           'CommandId': 'DoTransfer',
                           'CommandHandler': 'DoTransfer_CommandHandler',
                           'CommandHandlerExtension':'DoTransfer_CommandHandlerExtension'
                           }
        ],
        'BusinessControllerClass': 'Transfer_BusinessController',
    },
    'PresentationControllerConfig':{
        "Default":{
            'PresentationControllerClass': 'Transfer_PresentationController',
            'PresentationExtensions': ['Transfer_PresentationController_Extn']
        }
    },
            'Forms':[
                        {
               'FormName' : 'frmTransfer',
               'Controller' : 'frmTransferController',
               'FormController' : 'kony.mvc.MDAFormController',
               'ControllerExtensions' : []
            }
    ],
    'ModuleName': 'TransferModule'
};
